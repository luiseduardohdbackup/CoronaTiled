-- Project: Corona Tiled Map Loader Example 0.1
--
-- Date: November 24, 2012
-- Last Update: April 29, 2013
--
-- Version: 0.6
--
-- File name: main.lua
--
-- Author: Michael Wilson / NO2 Games, Inc. - www.no2games.com
--

--require('mobdebug').start()

display.setStatusBar( display.HiddenStatusBar )

display.setDefault( "magTextureFilter" , "nearest")
display.setDefault( "minTextureFilter" , "nearest")


local physics=require("physics")
local tiledMap = require("tiled")
physics.setDrawMode( "hybrid" )
physics.start()

map = tiledMap:load("demo.json")
map:setReferencePoint(display.CenterReferencePoint)
map.x = display.contentCenterX
map.y = display.contentCenterY

function map:touch( event )
		if event.phase == "began" then
				self.markX = self.x    -- store x location of object
				self.markY = self.y    -- store y location of object
		elseif event.phase == "moved" then
				local x = (event.x - event.xStart) + self.markX
				local y = (event.y - event.yStart) + self.markY
				self.x, self.y = x, y    -- move object based on calculations above
		end
		return true
end
map:addEventListener( "touch", map )